<?php 

$con=new mysqli('localhost','root','','laundry');

if(!$con)
{
	die(mysqli_error($con));
}

?>